import java.io.*;
import java.util.*;

public class Simulation {
    private Tablero tablero;
    private TreeSet<Integer> robots;
    private List<Store> stores;
    private int dias;

    // constructor: arranca con un tablero vacío de 10x10, sin robots ni tiendas
    public Simulation() {
        this.tablero = new Tablero(10);
        this.robots = new TreeSet<>();
        this.stores = new ArrayList<>();
        this.dias = 0;
    }

    // corre el modo default con los datos que vienen del enunciado del concurso
    public void runDefault() {
        int n = 6;
        int[][] input = {
            {1, 20},
            {2, 15, 15},
            {2, 40, 50},
            {1, 50},
            {2, 80, 20},
            {2, 70, 30}
        };

        this.dias = n;

        System.out.println("=== MODO DEFAULT (caso PDF ICPC 2024 J) ===");
        for (int day = 1; day <= n; day++) {
            int t = input[day - 1][0];
            int x = input[day - 1][1];

            if (t == 1) {
                // si es tipo 1, agrego un robot
                robots.add(x);
                tablero.agregarRobot(x % (tablero.getCellSize() * 10));
            } else {
                // si es tipo 2, agrego una tienda
                int c = input[day - 1][2];
                Store s = new Store(x, c, x);
                stores.add(s);
                tablero.agregarTienda(x % (tablero.getCellSize() * 10), c);
            }

            long profitToday = calcularBeneficio();
            System.out.println("Día " + day + " → Profit: " + profitToday);
        }
    }

    // corre el modo manual pidiendo datos al usuario por consola
    public void runManual() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Ingrese número de días: ");
        int n = sc.nextInt();
        this.dias = n;

        System.out.println("=== MODO MANUAL ===");
        for (int day = 1; day <= n; day++) {
            System.out.print("Día " + day + " (formato: 1 x  ó  2 x c): ");
            int t = sc.nextInt();
            int x = sc.nextInt();

            if (t == 1) {
                // si es tipo 1, agrego un robot
                robots.add(x);
                tablero.agregarRobot(x % (tablero.getCellSize() * 10));
            } else {
                // si es tipo 2, agrego una tienda
                int c = sc.nextInt();
                Store s = new Store(x, c, x);
                stores.add(s);
                tablero.agregarTienda(x % (tablero.getCellSize() * 10), c);
            }

            long profitToday = calcularBeneficio();
            System.out.println("Profit tras día " + day + ": " + profitToday);
        }
        sc.close();
    }

    // calcula el beneficio total actual según la distancia de cada tienda al robot más cercano
    private long calcularBeneficio() {
        if (robots.isEmpty() || stores.isEmpty()) return 0;

        long total = 0;
        for (Store store : stores) {
            int pos = store.getIndice();
            int tenges = store.getTenges();

            Integer left = robots.floor(pos);
            Integer right = robots.ceiling(pos);

            int dist = Integer.MAX_VALUE;
            if (left != null) dist = Math.min(dist, Math.abs(pos - left));
            if (right != null) dist = Math.min(dist, Math.abs(pos - right));

            long profit = tenges - dist;
            if (profit > 0) total += profit;
        }
        return total;
    }

    // método main: decide si correr en modo manual o default según los args
    public static void main(String[] args) throws IOException {
        Simulation sim = new Simulation();

        if (args.length > 0 && args[0].equals("manual")) {
            sim.runManual();
        } else {
            sim.runDefault();
        }
    }
}
