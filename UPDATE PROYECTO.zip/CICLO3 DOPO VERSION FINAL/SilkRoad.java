import java.util.*;

public class SilkRoad {
    private final int size;
    private final Tablero tablero;

    private final Map<Integer, Integer> tiendasDesocupadas = new HashMap<>();
    private final Map<Integer, List<Integer>> gananciasPorRobot = new HashMap<>();

    private final List<Store> tiendas = new ArrayList<>();
    private final List<Robot> robots = new ArrayList<>();

    private final List<Integer> storeCellIdx = new ArrayList<>();
    private final List<Integer> storeTenges = new ArrayList<>();
    private final List<Integer> storeOriginalId = new ArrayList<>();

    private final List<Integer> initialRobotPositions = new ArrayList<>();

    private int dia = 0;
    private boolean visible = false;

    public SilkRoad(int size, int[][] tiendasInput, int[][] robotsInput) {
        if (size <= 0) throw new IllegalArgumentException("Tamaño inválido");
        if (tiendasInput == null || robotsInput == null) throw new NullPointerException("Entradas nulas");

        this.size = size;
        this.tablero = new Tablero(size);

        // acá cargo todas las tiendas que vienen en la entrada
        for (int i = 0; i < tiendasInput.length; i++) {
            int[] t = tiendasInput[i];
            if (t == null || t.length < 2) continue;
            int idx = t[0];
            int tenges = t[1];
            int originalId = (t.length > 2) ? t[2] : i;
            if (idx < 0 || idx >= size * size) continue;

            int internalId = tiendas.size();
            Store s = new Store(idx, tenges, internalId);
            tiendas.add(s);
            storeCellIdx.add(idx);
            storeTenges.add(tenges);
            storeOriginalId.add(originalId);
            tiendasDesocupadas.put(internalId, 0);
            tablero.agregarTienda(idx, tenges);
        }

        // acá cargo todos los robots que vienen en la entrada
        for (int i = 0; i < robotsInput.length; i++) {
            int[] rRow = robotsInput[i];
            if (rRow == null || rRow.length < 1) continue;
            int idx = rRow[0];
            if (idx < 0 || idx >= size * size) continue;

            Robot r = new Robot(idx, java.awt.Color.blue);
            robots.add(r);
            initialRobotPositions.add(idx);
            gananciasPorRobot.put(i, new ArrayList<>());
            tablero.agregarRobot(idx);
        }
    }

    // mueve un robot según la regla de maximizar (tenges - distancia)
    public void moveRobot(int robotId) {
        if (robotId < 0 || robotId >= robots.size()) return;

        if (tiendas.isEmpty()) {
            gananciasPorRobot.get(robotId).add(0);
            return;
        }

        Robot r = robots.get(robotId);
        int origen = r.getIndice();

        int mejorGanancia = Integer.MIN_VALUE;
        int mejorDistancia = Integer.MAX_VALUE;
        int mejorTenges = Integer.MIN_VALUE;
        int mejorDestino = origen;
        int mejorStoreInternalId = -1;

        for (int id = 0; id < tiendas.size(); id++) {
            int destino = storeCellIdx.get(id);
            int tenges = storeTenges.get(id);
            int dist = Math.abs(origen - destino);
            int ganancia = tenges - dist;

            boolean mejor = false;
            if (ganancia > mejorGanancia) {
                mejor = true;
            } else if (ganancia == mejorGanancia) {
                if (dist < mejorDistancia) {
                    mejor = true;
                } else if (dist == mejorDistancia) {
                    if (tenges > mejorTenges) {
                        mejor = true;
                    } else if (tenges == mejorTenges && destino < mejorDestino) {
                        mejor = true;
                    }
                }
            }

            if (mejor) {
                mejorGanancia = ganancia;
                mejorDistancia = dist;
                mejorTenges = tenges;
                mejorDestino = destino;
                mejorStoreInternalId = id;
            }
        }

        boolean moved = (mejorDestino != origen);
        if (moved) {
            tablero.moverRobot(robotId, mejorDestino);
            robots.get(robotId).setIndice(mejorDestino);
            if (mejorStoreInternalId >= 0) {
                tiendasDesocupadas.put(
                    mejorStoreInternalId,
                    tiendasDesocupadas.getOrDefault(mejorStoreInternalId, 0) + 1
                );
            }
        }

        int recordedGain = 0;
        if (mejorStoreInternalId >= 0) {
            int tenges = storeTenges.get(mejorStoreInternalId);
            if (tenges == 0) {
                recordedGain = 0;
            } else {
                recordedGain = storeOriginalId.get(mejorStoreInternalId);
            }
        }
        gananciasPorRobot.get(robotId).add(recordedGain);
    }

    // simula un día completo moviendo todos los robots
    public void simularDia() {
        for (int i = 0; i < robots.size(); i++) {
            moveRobot(i);
        }
        dia++;
        for (int i = 0; i < robots.size(); i++) {
            List<Integer> g = gananciasPorRobot.get(i);
            while (g.size() < dia) g.add(0);
        }
    }

    // reinicia los robots a su posición inicial y avanza un día
    public void reboot() {
        for (int i = 0; i < robots.size(); i++) {
            int initialPos = initialRobotPositions.get(i);
            int current = robots.get(i).getIndice();
            if (current != initialPos) {
                tablero.moverRobot(i, initialPos);
                robots.get(i).setIndice(initialPos);
            }
            gananciasPorRobot.get(i).add(0);
        }
        dia++;
        for (int i = 0; i < robots.size(); i++) {
            List<Integer> g = gananciasPorRobot.get(i);
            while (g.size() < dia) g.add(0);
        }
    }

    // devuelve copia de las ganancias de cada robot
    public Map<Integer, List<Integer>> consultGananciasRobots() {
        Map<Integer, List<Integer>> copia = new HashMap<>();
        for (Map.Entry<Integer, List<Integer>> e : gananciasPorRobot.entrySet()) {
            copia.put(e.getKey(), new ArrayList<>(e.getValue()));
        }
        return copia;
    }

    // devuelve copia de cuántas veces se desocupó cada tienda
    public Map<Integer, Integer> consultTiendasDesocupadas() {
        Map<Integer, Integer> copia = new HashMap<>();
        for (int id = 0; id < tiendas.size(); id++) {
            copia.put(id, tiendasDesocupadas.getOrDefault(id, 0));
        }
        return copia;
    }

    // devuelve el robot con mayor ganancia acumulada
    public int getRobotConMayorGanancia() {
        int mejor = -1;
        int max = -1;
        for (Map.Entry<Integer, List<Integer>> e : gananciasPorRobot.entrySet()) {
            int suma = e.getValue().stream().mapToInt(Integer::intValue).sum();
            if (suma > max) {
                max = suma;
                mejor = e.getKey();
            }
        }
        return mejor;
    }

    // devuelve un string con info general de la simulación
    public String getInfo() {
        StringBuilder sb = new StringBuilder();
        sb.append("Día ").append(dia).append("\n");
        sb.append("Robots: ").append(robots.size()).append("\n");
        sb.append("Tiendas: ").append(tiendas.size()).append("\n");
        for (int i = 0; i < robots.size(); i++) {
            sb.append("Robot ").append(i).append(" → ").append(gananciasPorRobot.get(i)).append("\n");
        }
        return sb.toString();
    }

    // hace visible el tablero
    public void makeVisible() {
        visible = true;
        refrescar();
    }

    // oculta el tablero
    public void makeInvisible() {
        visible = false;
        refrescar();
    }

    // refresca el tablero si está visible
    private void refrescar() {
        if (visible) tablero.dibujaTablero();
    }

    // devuelve el tablero
    public Tablero getTablero() {
        return tablero;
    }
}
