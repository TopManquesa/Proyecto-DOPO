import java.awt.*;

public class Robot {
    private int indice;
    private Color color;
    private boolean titilando;
    private String visualId;

    public Robot(int indice, Color color) {
        this.indice = indice;
        this.color = color;
        this.visualId = "robot_" + System.identityHashCode(this);
    }

    // devuelve en qué casilla está el robot
    public int getIndice() { return indice; }

    // cambia la casilla donde está el robot
    public void setIndice(int indice) { this.indice = indice; }

    // activa o desactiva el modo "titilando" (parpadeo)
    public void setTitilando(boolean titilando) { this.titilando = titilando; }

    // se llama en cada tick, por ahora no hace nada pero sirve para animaciones
    public void onTick() { }

    // dibuja el robot en el canvas, usando su posición y color
    public void dibujar(Canvas canvas, Tablero tablero) {
        Point p = tablero.obtenerPixelDeIndice(indice);
        int cellSize = tablero.getCellSize();
        int x = p.x + cellSize / 4;
        int y = p.y + cellSize / 4;
        int size = cellSize / 2;
        Shape circle = new java.awt.geom.Ellipse2D.Double(x, y, size, size);
        String fill = titilando ? "red" : "blue";
        canvas.draw(visualId, fill, circle);
    }
}
