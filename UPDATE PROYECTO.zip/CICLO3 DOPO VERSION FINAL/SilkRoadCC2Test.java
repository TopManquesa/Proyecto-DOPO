import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.*;

/**
 * Propuesta de casos de prueba para la clase colectiva SilkRoadCC2Test.
 * Los nombres incluyen identificación de autores (reemplazar XX con iniciales).
 */
public class SilkRoadCC2Test {   
    /**
     * Caso de prueba propuesto: Verificar que se puede crear una ruta con entrada válida de maratón.
     * Autores: XX (reemplazar con sus iniciales)
     */
    @Test
    public void accordingXXShouldCreateValidSilkRoadFromMarathonInput() {
        int[][] tiendas = {{0, 10, 5}, {2, 15, 8}, {4, 20, 3}};
        int[][] robots = {{1}, {3}};
        
        SilkRoad silkRoad = new SilkRoad(6, tiendas, robots);
        
        assertNotNull(silkRoad);
        assertEquals(3, silkRoad.consultTiendasDesocupadas().size());
        assertEquals(2, silkRoad.consultGananciasRobots().size());
    }
    
    /**
     * Caso de prueba propuesto: Verificar que los robots buscan maximizar ganancias.
     * Autores: XX (reemplazar con sus iniciales)
     */
    @Test
    public void accordingXXShouldMoveRobotToMaximizeProfit() {
    
        int[][] tiendas = {{1, 10, 2}, {2, 10, 20}};
        int[][] robots = {{0}};
        
        SilkRoad silkRoad = new SilkRoad(5, tiendas, robots);
        silkRoad.moveRobot(0);
        
        Map<Integer, List<Integer>> ganancias = silkRoad.consultGananciasRobots();
        int ganancia = ganancias.get(0).get(0);
        
        assertTrue(ganancia > 0);
    }
    
    /**
     * Caso de prueba propuesto: Verificar consulta de tiendas desocupadas.
     * Autores: XX (reemplazar con sus iniciales)
     */
    @Test
    public void accordingXXShouldTrackEmptyStoresCorrectly() {
        int[][] tiendas = {{1, 1, 10}}; 
        int[][] robots = {{0}};
        
        SilkRoad silkRoad = new SilkRoad(3, tiendas, robots);
        
        assertEquals(0, silkRoad.consultTiendasDesocupadas().get(0).intValue());
        
        silkRoad.moveRobot(0);
        assertEquals(1, silkRoad.consultTiendasDesocupadas().get(0).intValue());
    }
    
    /**
     * Caso de prueba propuesto: Verificar consulta de ganancias por movimiento.
     * Autores: XX (reemplazar con sus iniciales)
     */
    @Test
    public void accordingXXShouldRecordGainsPerMovementCorrectly() {
        int[][] tiendas = {{1, 5, 10}, {3, 5, 15}};
        int[][] robots = {{0}};
        
        SilkRoad silkRoad = new SilkRoad(5, tiendas, robots);
        
        silkRoad.moveRobot(0); 
        silkRoad.moveRobot(0); 
        
        Map<Integer, List<Integer>> ganancias = silkRoad.consultGananciasRobots();
        List<Integer> ganarciasRobot0 = ganancias.get(0);
        
        assertEquals(2, ganarciasRobot0.size());
        assertTrue(ganarciasRobot0.get(0) >= 0);
        assertTrue(ganarciasRobot0.get(1) >= 0);
    }
    
    /**
     * Caso de prueba propuesto: Verificar reboot funciona correctamente.
     * Autores: XX (reemplazar con sus iniciales)
     */
    @Test
    public void accordingXXShouldRebootSystemCorrectly() {
        int[][] tiendas = {{1, 2, 10}};
        int[][] robots = {{0}};
        
        SilkRoad silkRoad = new SilkRoad(3, tiendas, robots);
        
        silkRoad.moveRobot(0);
        silkRoad.moveRobot(0);
        
        assertEquals(1, silkRoad.consultTiendasDesocupadas().get(0).intValue());
        
        silkRoad.reboot();
        
        silkRoad.moveRobot(0);
        Map<Integer, List<Integer>> ganancias = silkRoad.consultGananciasRobots();
        
        assertTrue(ganancias.get(0).size() > 2);
    }
    
    /**
     * Caso de prueba propuesto: Verificar identificación del robot ganador.
     * Autores: XX (reemplizar con sus iniciales)
     */
    @Test
    public void accordingXXShouldIdentifyWinningRobotCorrectly() {
        int[][] tiendas = {{1, 10, 5}, {3, 10, 15}};
        int[][] robots = {{0}, {2}};
        
        SilkRoad silkRoad = new SilkRoad(5, tiendas, robots);
        
        silkRoad.moveRobot(1); 
        silkRoad.moveRobot(0); 
        
        int robotGanador = silkRoad.getRobotConMayorGanancia();
        assertTrue(robotGanador == 0 || robotGanador == 1);
    }
    
    /**
     * Caso de prueba propuesto: Verificar manejo de casos extremos.
     * Autores: XX (reemplazar con sus iniciales)
     */
    @Test
    public void accordingXXShouldHandleEdgeCaseGracefully() {

        int[][] tiendas = {{1, 0, 10}, {2, 0, 15}};
        int[][] robots = {{0}};
        
        SilkRoad silkRoad = new SilkRoad(4, tiendas, robots);
        
        silkRoad.moveRobot(0);
        
        Map<Integer, List<Integer>> ganancias = silkRoad.consultGananciasRobots();
        assertEquals(1, ganancias.get(0).size());
        assertEquals(0, ganancias.get(0).get(0).intValue());
    }
    
    /**
     * Caso de prueba propuesto: Verificar integridad de datos en consultas.
     * Autores: XX (reemplazar con sus iniciales)
     */
    @Test
    public void accordingXXShouldMaintainDataIntegrityInConsults() {
        int[][] tiendas = {{1, 5, 10}};
        int[][] robots = {{0}};
        
        SilkRoad silkRoad = new SilkRoad(3, tiendas, robots);
        silkRoad.moveRobot(0);
        
        Map<Integer, List<Integer>> ganancias = silkRoad.consultGananciasRobots();
        Map<Integer, Integer> tiendas_desocupadas = silkRoad.consultTiendasDesocupadas();
        
        ganancias.get(0).add(999);
        tiendas_desocupadas.put(0, 999);
        
        Map<Integer, List<Integer>> nuevasGanancias = silkRoad.consultGananciasRobots();
        Map<Integer, Integer> nuevasTiendas = silkRoad.consultTiendasDesocupadas();
        
        assertNotEquals(999, nuevasGanancias.get(0).get(nuevasGanancias.get(0).size() - 1));
        assertNotEquals(999, nuevasTiendas.get(0));
    }
    
    /**
     * Caso de prueba propuesto: Verificar simulación de día completo.
     * Autores: XX (reemplazar con sus iniciales)  
     */
    @Test
    public void accordingXXShouldSimulateCompleteDayCorrectly() {
        int[][] tiendas = {{1, 10, 5}, {3, 10, 8}};
        int[][] robots = {{0}, {2}};
        
        SilkRoad silkRoad = new SilkRoad(5, tiendas, robots);
        
        silkRoad.simularDia();
        
        Map<Integer, List<Integer>> ganancias = silkRoad.consultGananciasRobots();
        
        assertEquals(1, ganancias.get(0).size());
        assertEquals(1, ganancias.get(1).size());
    }
    
    /**
     * Caso de prueba propuesto: Verificar que no se permite entrada inválida.
     * Autores: XX (reemplazar con sus iniciales)
     */
    @Test
    public void accordingXXShouldNotAllowInvalidInput() {
        int[][] tiendasValidas = {{1, 10, 5}};
        int[][] robotsValidos = {{0}};
        
        assertThrows(IllegalArgumentException.class, () -> {
            new SilkRoad(-1, tiendasValidas, robotsValidos);
        });
        
        assertThrows(NullPointerException.class, () -> {
            new SilkRoad(5, null, robotsValidos);
        });
        
        assertThrows(NullPointerException.class, () -> {
            new SilkRoad(5, tiendasValidas, null);
        });
    }
    
    /**
     * Caso de prueba propuesto: Verificar consistencia en múltiples reinicios.
     * Autores: XX (reemplazar con sus iniciales)
     */
    @Test
    public void accordingXXShouldMaintainConsistencyThroughMultipleReboots() {
        int[][] tiendas = {{1, 3, 10}};
        int[][] robots = {{0}};
        
        SilkRoad silkRoad = new SilkRoad(3, tiendas, robots);
        
        // Primer ciclo
        silkRoad.moveRobot(0);
        silkRoad.moveRobot(0);
        silkRoad.moveRobot(0); 
        
        int desocupadasCiclo1 = silkRoad.consultTiendasDesocupadas().get(0);
        
        silkRoad.reboot();
        
        //segundo ciclo
        silkRoad.moveRobot(0);
        silkRoad.moveRobot(0);
        silkRoad.moveRobot(0);
        
        int desocupadasCiclo2 = silkRoad.consultTiendasDesocupadas().get(0);
        
        assertTrue(desocupadasCiclo2 > desocupadasCiclo1);
    }
    
    /**
     * Caso de prueba propuesto: Verificar estrategia de maximización con distancias.
     * Autores: XX (reemplazar con sus iniciales)
     */
    @Test
    public void accordingXXShouldOptimizeForDistanceAndProfit() {
        int[][] tiendas = {{1, 10, 5}, {5, 10, 20}};
        int[][] robots = {{0}};
        
        SilkRoad silkRoad = new SilkRoad(7, tiendas, robots);
        
        silkRoad.moveRobot(0);
        
        Map<Integer, List<Integer>> ganancias = silkRoad.consultGananciasRobots();
        int ganancia = ganancias.get(0).get(0);
        
        assertTrue(ganancia > 0);
        
        assertTrue(ganancia == 5 || ganancia == 20);
    }
    
    /**
     * Caso de prueba propuesto: Verificar concurrencia en parpadeo de robot ganador.
     * Autores: XX (reemplazar con sus iniciales)
     */
    @Test
    public void accordingXXShouldHandleWinnerBlinkingCorrectly() {
        int[][] tiendas = {{1, 10, 10}, {3, 5, 5}};
        int[][] robots = {{0}, {2}};
        
        SilkRoad silkRoad = new SilkRoad(5, tiendas, robots);
        
        silkRoad.moveRobot(0); 
        silkRoad.moveRobot(1); 
        
        int ganador = silkRoad.getRobotConMayorGanancia();
        assertTrue(ganador == 0 || ganador == 1);
        
        silkRoad.simularDia();
        int nuevoGanador = silkRoad.getRobotConMayorGanancia();
        assertTrue(nuevoGanador == 0 || nuevoGanador == 1);
    }
    
    /**
     * Caso de prueba propuesto: Verificar información del sistema.
     * Autores: XX (reemplazar con sus iniciales)
     */
    @Test
    public void accordingXXShouldProvideCorrectSystemInfo() {
        int[][] tiendas = {{1, 10, 5}, {2, 15, 8}};
        int[][] robots = {{0}, {3}};
        
        SilkRoad silkRoad = new SilkRoad(5, tiendas, robots);
        
        String info = silkRoad.getInfo();
        
        assertNotNull(info);
        assertTrue(info.contains("Día"));
        assertTrue(info.contains("Robots: 2"));
        assertTrue(info.contains("Tiendas: 2"));
        assertTrue(info.contains("Robot 0"));
        assertTrue(info.contains("Robot 1"));
    }
    
    /**
     * Caso de prueba propuesto: Verificar manejo de robots sin movimientos válidos.
     * Autores: XX (reemplazar con sus iniciales)
     */
    @Test
    public void accordingXXShouldHandleRobotsWithNoValidMoves() {
        int[][] tiendas = {};
        int[][] robots = {{0}, {2}};
        
        SilkRoad silkRoad = new SilkRoad(5, tiendas, robots);
        
        silkRoad.moveRobot(0);
        silkRoad.moveRobot(1);
        
        Map<Integer, List<Integer>> ganancias = silkRoad.consultGananciasRobots();
        
        assertEquals(1, ganancias.get(0).size());
        assertEquals(1, ganancias.get(1).size());
        assertEquals(0, ganancias.get(0).get(0).intValue());
        assertEquals(0, ganancias.get(1).get(0).intValue());
    }
    
    /**
     * Caso de prueba propuesto: Verificar escalabilidad con muchos robots y tiendas.
     * Autores: XX (reemplazar con sus iniciales)
     */
    @Test
    public void accordingXXShouldHandleLargeScaleScenarios() {
        int numTiendas = 10;
        int numRobots = 5;
        
        int[][] tiendas = new int[numTiendas][3];
        for (int i = 0; i < numTiendas; i++) {
            tiendas[i] = new int[]{i + 1, 10, i + 1};
        }
        
        int[][] robots = new int[numRobots][1];
        for (int i = 0; i < numRobots; i++) {
            robots[i] = new int[]{i * 2};
        }
        
        SilkRoad silkRoad = new SilkRoad(20, tiendas, robots);
        
        for (int dia = 0; dia < 3; dia++) {
            silkRoad.simularDia();
            silkRoad.reboot();
        }
        
        Map<Integer, List<Integer>> ganancias = silkRoad.consultGananciasRobots();
        Map<Integer, Integer> tiendasDesocupadas = silkRoad.consultTiendasDesocupadas();
        
        assertEquals(numRobots, ganancias.size());
        assertEquals(numTiendas, tiendasDesocupadas.size());
        
        for (List<Integer> movimientos : ganancias.values()) {
            assertTrue(movimientos.size() >= 3);
        }
    }
    
    /**
     * Caso de prueba propuesto: Verificar que la visualización no afecta la lógica.
     * Autores: XX (reemplazar con sus iniciales)
     */
    @Test
    public void accordingXXShouldMaintainLogicIndependentOfVisualization() {
        int[][] tiendas = {{1, 5, 10}};
        int[][] robots = {{0}};
        
        SilkRoad silkRoadVisible = new SilkRoad(3, tiendas, robots);
        SilkRoad silkRoadInvisible = new SilkRoad(3, tiendas, robots);
        
        silkRoadVisible.makeVisible();
  
        silkRoadVisible.moveRobot(0);
        silkRoadInvisible.moveRobot(0);
        

        Map<Integer, List<Integer>> gananciasVisible = silkRoadVisible.consultGananciasRobots();
        Map<Integer, List<Integer>> gananciasInvisible = silkRoadInvisible.consultGananciasRobots();
        
        assertEquals(gananciasVisible, gananciasInvisible);
        
        silkRoadVisible.makeInvisible();
    }
}