import java.awt.Color;
import java.awt.Point;
import java.awt.Shape;
import java.awt.Rectangle;
import java.util.*;
import javax.swing.Timer;

public class Tablero {
    private final int size;
    private final Map<Integer, Point> indiceACasilla;
    private final List<Point> ordenEspiral;
    private final Canvas canvas;

    private final int cellSize = 50;
    private final int offsetY = 40;

    private final List<Robot> robots = new ArrayList<>();
    private final List<Store> tiendas = new ArrayList<>();

    private final Timer tickTimer;
    private boolean animacionesActivas = true;

    public Tablero(int size) {
        this.size = size;
        this.indiceACasilla = new HashMap<>(size * size);
        this.ordenEspiral = new ArrayList<>(size * size);

        int width = size * cellSize + 1;
        int height = size * cellSize + offsetY + 1;
        this.canvas = Canvas.getCanvas("Tablero", width, height, Color.white);

        generaIndicesPorRenglones();
        generarOrdenEspiral();
        dibujaTableroAnimado();

        tickTimer = new Timer(300, e -> tick());
        tickTimer.start();
    }

    // activa o desactiva las animaciones
    public void setAnimaciones(boolean activas) {
        this.animacionesActivas = activas;
    }

    // devuelve el tamaño del tablero (n x n)
    public int getSize() { return size; }

    // devuelve el tamaño de cada celda en pixeles
    public int getCellSize() { return cellSize; }

    // devuelve el offset vertical (espacio arriba del tablero)
    public int getOffsetY() { return offsetY; }

    // genera el mapa de índices a coordenadas (fila, col)
    private void generaIndicesPorRenglones() {
        int index = 0;
        for (int fila = 0; fila < size; fila++) {
            for (int col = 0; col < size; col++) {
                indiceACasilla.put(index, new Point(col, fila));
                index++;
            }
        }
    }

    // genera el orden en espiral para dibujar animado
    private void generarOrdenEspiral() {
        int top = 0, bottom = size - 1;
        int left = 0, right = size - 1;
        ordenEspiral.clear();

        while (top <= bottom && left <= right) {
            for (int col = left; col <= right; col++) ordenEspiral.add(new Point(col, top));
            top++;
            for (int row = top; row <= bottom; row++) ordenEspiral.add(new Point(right, row));
            right--;
            if (top <= bottom) {
                for (int col = right; col >= left; col--) ordenEspiral.add(new Point(col, bottom));
                bottom--;
            }
            if (left <= right) {
                for (int row = bottom; row >= top; row--) ordenEspiral.add(new Point(left, row));
                left++;
            }
        }
    }

    // dibuja el tablero con animación (espiral)
    private void dibujaTableroAnimado() {
        for (Point pos : ordenEspiral) {
            int col = pos.x;
            int fila = pos.y;
            int px = col * cellSize;
            int py = fila * cellSize + offsetY;

            Shape rect = new Rectangle(px, py, cellSize, cellSize);
            String color = ((fila + col) % 2 == 0) ? "white" : "black";
            canvas.draw("cell_" + fila + "_" + col, color, rect);

            Shape lineaH = new java.awt.geom.Line2D.Double(0, py, size * cellSize, py);
            Shape lineaV = new java.awt.geom.Line2D.Double(px, offsetY, px, size * cellSize + offsetY);
            canvas.draw("gridH_" + fila + "_" + col, "#BBBBBB", lineaH);
            canvas.draw("gridV_" + fila + "_" + col, "#BBBBBB", lineaV);

            canvas.wait(50);
        }

        Shape lineaHFinal = new java.awt.geom.Line2D.Double(0, size * cellSize + offsetY, size * cellSize, size * cellSize + offsetY);
        Shape lineaVFinal = new java.awt.geom.Line2D.Double(size * cellSize, offsetY, size * cellSize, size * cellSize + offsetY);
        canvas.draw("gridH_final", "#BBBBBB", lineaHFinal);
        canvas.draw("gridV_final", "#BBBBBB", lineaVFinal);

        refrescarElementos();
    }

    // dibuja el tablero de golpe (sin animación)
    public void dibujaTablero() {
        for (int fila = 0; fila < size; fila++) {
            for (int col = 0; col < size; col++) {
                int px = col * cellSize;
                int py = fila * cellSize + offsetY;
                Shape rect = new Rectangle(px, py, cellSize, cellSize);
                String color = ((fila + col) % 2 == 0) ? "white" : "black";
                canvas.draw("cell_" + fila + "_" + col, color, rect);

                Shape lineaH = new java.awt.geom.Line2D.Double(0, py, size * cellSize, py);
                Shape lineaV = new java.awt.geom.Line2D.Double(px, offsetY, px, size * cellSize + offsetY);
                canvas.draw("gridH_" + fila + "_" + col, "#BBBBBB", lineaH);
                canvas.draw("gridV_" + fila + "_" + col, "#BBBBBB", lineaV);
            }
        }

        Shape lineaHFinal = new java.awt.geom.Line2D.Double(0, size * cellSize + offsetY, size * cellSize, size * cellSize + offsetY);
        Shape lineaVFinal = new java.awt.geom.Line2D.Double(size * cellSize, offsetY, size * cellSize, size * cellSize + offsetY);
        canvas.draw("gridH_final", "#BBBBBB", lineaHFinal);
        canvas.draw("gridV_final", "#BBBBBB", lineaVFinal);

        refrescarElementos();
    }

    // se llama cada cierto tiempo para refrescar animaciones
    private void tick() {
        for (Robot r : robots) r.onTick();
        refrescarElementos();
    }

    // redibuja todas las tiendas y robots
    private void refrescarElementos() {
        for (Store t : tiendas) t.dibujar(canvas, this);
        for (Robot r : robots) {
            boolean sobreTienda = false;
            for (Store t : tiendas) {
                if (r.getIndice() == t.getIndice()) {
                    sobreTienda = true;
                    break;
                }
            }
            r.setTitilando(sobreTienda);
            r.dibujar(canvas, this);
        }
    }

    // devuelve la posición en pixeles de un índice de casilla
    public Point obtenerPixelDeIndice(int index) {
        Point casilla = indiceACasilla.get(index);
        if (casilla == null) return new Point(0, offsetY);
        int px = casilla.x * cellSize;
        int py = casilla.y * cellSize + offsetY;
        return new Point(px, py);
    }

    // agrega un robot en el tablero
    public void agregarRobot(int indice) {
        if (indice < 0 || indice >= size * size) return;
        robots.add(new Robot(indice, Color.blue));
        refrescarElementos();
    }

    // agrega una tienda en el tablero
    public void agregarTienda(int indice, int tenges) {
        if (indice < 0 || indice >= size * size) return;
        tiendas.add(new Store(indice, tenges, indice));
        refrescarElementos();
    }

    // mueve un robot paso a paso hasta un nuevo índice
    public void moverRobot(int robotIndex, int nuevoIndice) {
        if (robotIndex < 0 || robotIndex >= robots.size()) return;
        if (nuevoIndice < 0 || nuevoIndice >= size * size) return;

        Robot r = robots.get(robotIndex);
        int origen = r.getIndice();
        int paso = (nuevoIndice > origen) ? 1 : -1;
        for (int i = origen; i != nuevoIndice; i += paso) {
            r.setIndice(i);
            refrescarElementos();
            if (animacionesActivas) canvas.wait(50);
        }
        r.setIndice(nuevoIndice);
        refrescarElementos();
    }

    // devuelve la lista de robots
    public List<Robot> getRobots() { return robots; }

    // devuelve la lista de tiendas
    public List<Store> getTiendas() { return tiendas; }
}
