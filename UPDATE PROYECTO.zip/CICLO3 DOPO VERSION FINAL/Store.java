import java.awt.*;

public class Store {
    private int indice;
    private int tenges;
    private int id;
    private String visualId;

    public Store(int indice, int tenges, int id) {
        this.indice = indice;
        this.tenges = tenges;
        this.id = id;
        this.visualId = "store_" + System.identityHashCode(this);
    }

    // devuelve la casilla donde está la tienda
    public int getIndice() { return indice; }

    // cambia la casilla de la tienda
    public void setIndice(int indice) { this.indice = indice; }

    // devuelve cuántos tenges tiene la tienda
    public int getTenges() { return tenges; }

    // cambia los tenges de la tienda
    public void setTenges(int tenges) { this.tenges = tenges; }

    // devuelve el id de la tienda
    public int getId() { return id; }

    // dibuja la tienda en el canvas como un cuadrado amarillo
    public void dibujar(Canvas canvas, Tablero tablero) {
        Point p = tablero.obtenerPixelDeIndice(indice);
        int cellSize = tablero.getCellSize();
        int x = p.x + cellSize / 4;
        int y = p.y + cellSize / 4;
        int size = cellSize / 2;
        Shape square = new java.awt.Rectangle(x, y, size, size);
        canvas.draw(visualId, "yellow", square);
    }
}
