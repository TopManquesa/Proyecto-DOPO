import java.awt.*;
import java.awt.image.BufferedImage;
import javax.swing.*;
import java.util.LinkedHashMap;
import java.util.Map;

public class Canvas {
    private static Canvas canvasSingleton;

    private final JFrame frame;
    private final CanvasPane canvas;
    private final Graphics2D graphic;
    private Color backgroundColor;
    private final Image canvasImage;

    // Mantener orden de dibujo estable (evita parpadeos y superposiciones inesperadas)
    private final Map<Object, ShapeDescription> shapes;

    // Constructor privado (patrón singleton)
    private Canvas(String title, int width, int height, Color bgColor) {
        frame = new JFrame();
        canvas = new CanvasPane();
        frame.setContentPane(canvas);
        frame.setTitle(title);
        frame.setSize(width, height);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);

        backgroundColor = bgColor != null ? bgColor : Color.white;
        canvasImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        graphic = (Graphics2D) canvasImage.getGraphics();
        graphic.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        graphic.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);

        // Fondo inicial
        graphic.setColor(backgroundColor);
        graphic.fillRect(0, 0, width, height);

        // LinkedHashMap para preservar orden de inserción
        shapes = new LinkedHashMap<>();
    }

    // API original sin parámetros: muchas clases (Circle/Triangle/Rectangle/ProgressBar) la usan
    public static Canvas getCanvas() {
        if (canvasSingleton == null) {
            canvasSingleton = new Canvas("Canvas", 600, 400, Color.white);
        }
        return canvasSingleton;
    }

    // Sobrecarga adicional para Tablero (título/tamaño/color)
    public static Canvas getCanvas(String title, int width, int height, Color bgColor) {
        if (canvasSingleton == null) {
            canvasSingleton = new Canvas(title, width, height, bgColor);
        } else {
            canvasSingleton.frame.setTitle(title);
            canvasSingleton.frame.setSize(width, height);
            canvasSingleton.setBackgroundColor(bgColor != null ? bgColor : Color.white);
        }
        return canvasSingleton;
    }

    // Método central que la librería de BlueJ usa (compatibilidad con tus clases)
    public void draw(Object referenceObject, String color, Shape shape) {
        shapes.put(referenceObject, new ShapeDescription(shape, parseColor(color)));
        redraw();
    }

    // Sobrecarga por Color directo (por si alguna clase la usa)
    public void draw(Object referenceObject, Color color, Shape shape) {
        shapes.put(referenceObject, new ShapeDescription(shape, color));
        redraw();
    }

    // Borrar un elemento por su referencia
    public void erase(Object referenceObject) {
        shapes.remove(referenceObject);
        redraw();
    }

    // Borrar todo
    public void eraseAll() {
        shapes.clear();
        redraw();
    }

    // Espera (para animaciones)
    public void wait(int milliseconds) {
        try { Thread.sleep(milliseconds); } catch (InterruptedException e) { /* ignore */ }
    }

    // Opcional: establecer color de fondo
    public void setBackgroundColor(Color bg) {
        if (bg == null) return;
        this.backgroundColor = bg;
        // Repintar fondo del buffer
        Dimension size = canvas.getSize();
        graphic.setColor(backgroundColor);
        graphic.fillRect(0, 0, size.width, size.height);
        redraw();
    }

    // Opcional: utilidad para dibujar texto (si ProgressBar u otros lo requieren)
    public void drawString(String text, int x, int y, String color) {
        // Se dibuja inmediatamente sobre el buffer, no se guarda en 'shapes'
        Color c = parseColor(color);
        Color old = graphic.getColor();
        graphic.setColor(c);
        graphic.drawString(text, x, y);
        graphic.setColor(old);
        canvas.repaint();
    }

    // Repintado del buffer y refresco del panel
    private void redraw() {
        Dimension size = canvas.getSize();
        // Limpia fondo
        graphic.setColor(backgroundColor);
        graphic.fillRect(0, 0, size.width, size.height);

        // Dibuja en orden estable
        for (ShapeDescription desc : shapes.values()) {
            graphic.setColor(desc.color);
            // Líneas con draw; figuras cerradas con fill
            if (desc.shape instanceof java.awt.geom.Line2D) {
                Stroke old = graphic.getStroke();
                graphic.setStroke(new BasicStroke(1f));
                graphic.draw(desc.shape);
                graphic.setStroke(old);
            } else {
                graphic.fill(desc.shape);
            }
        }
        canvas.repaint();
    }

    // Conversión de nombres/hex a Color (compatibilidad)
    private Color parseColor(String colorStr) {
        if (colorStr == null) return Color.black;
        try {
            if (colorStr.startsWith("#")) return Color.decode(colorStr);
            switch (colorStr.toLowerCase()) {
                case "black": return Color.black;
                case "white": return Color.white;
                case "red": return Color.red;
                case "green": return Color.green;
                case "blue": return Color.blue;
                case "yellow": return Color.yellow;
                case "gray": return Color.gray;
                case "lightgray": return Color.lightGray;
                case "darkgray": return Color.darkGray;
                case "orange": return Color.orange;
                case "pink": return Color.pink;
                case "cyan": return Color.cyan;
                case "magenta": return Color.magenta;
                default: return Color.black;
            }
        } catch (Exception e) {
            return Color.black;
        }
    }

    // Panel de dibujo
    private class CanvasPane extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            g.drawImage(canvasImage, 0, 0, null);
        }
    }

    // Descriptor de figura
    private static class ShapeDescription {
        final Shape shape;
        final Color color;
        ShapeDescription(Shape shape, Color color) {
            this.shape = shape;
            this.color = color;
        }
    }
}
