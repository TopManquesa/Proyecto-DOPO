import java.awt.Color;
import java.awt.Rectangle;

public class ProgressBar {
    private final Canvas canvas;
    private final Tablero tablero;

    private final int width;
    private final int height;

    private int maxValue;
    private int current;

    private final String KEY_BG   = "pb_bg";
    private final String KEY_FILL = "pb_fill";
    private final String KEY_TEXT = "pb_text";

    public ProgressBar(Tablero tablero, int width, int height, int maxValue) {
        this.tablero = tablero;
        this.canvas = Canvas.getCanvas();
        this.width = width;
        this.height = height;
        this.maxValue = Math.max(1, maxValue);
        this.current = 0;
        redraw();
    }

    // cambia el valor máximo de la barra y la vuelve a dibujar
    public void setMaxValue(int max) {
        this.maxValue = Math.max(1, max);
        redraw();
    }

    // actualiza el progreso actual y redibuja la barra
    public void updateProgress(int value) {
        this.current = Math.max(0, value);
        redraw();
    }

    // dibuja la barra completa (fondo, relleno y texto)
    private void redraw() {
        int x = 0;
        int y = Math.max(0, tablero.getOffsetY() / 2 - height / 2);

        canvas.draw(KEY_BG, "lightgray", new Rectangle(x, y, width, height));

        int fillW = (int) Math.min(width, (width * (double) current) / maxValue);
        canvas.draw(KEY_FILL, "green", new Rectangle(x, y, fillW, height));

        String texto = current + " / " + maxValue;
        int tx = x + width / 2 - (texto.length() * 3);
        int ty = y + height / 2 + 5;

        canvas.draw(KEY_TEXT, "black", new java.awt.geom.Rectangle2D.Double(tx, ty, 1, 1));
        canvas.drawString(texto, tx, ty, "black");
    }
}
