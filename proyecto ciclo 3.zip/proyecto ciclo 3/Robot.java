import java.awt.*;

public class Robot {
    private int indice;
    private Color color;
    private String id; // id único y persistente

    public Robot(int indice, Color color) {
        this.indice = indice;
        this.color = color;
        this.id = "robot_" + System.identityHashCode(this);
    }

    public int getIndice() { return indice; }
    public void setIndice(int indice) { this.indice = indice; }

    public void dibujar(Canvas canvas, Tablero tablero) {
        Point p = tablero.obtenerPixelDeIndice(indice);
        int cellSize = tablero.getCellSize();

        int x = p.x + cellSize / 4;
        int y = p.y + cellSize / 4;
        int size = cellSize / 2;

        Shape circle = new java.awt.geom.Ellipse2D.Double(x, y, size, size);

        // 👇 siempre el mismo id, pero se redibuja en la nueva posición
        canvas.draw(id, colorToString(color), circle);
    }

    private String colorToString(Color c) {
        if (c.equals(Color.RED)) return "red";
        if (c.equals(Color.BLUE)) return "blue";
        if (c.equals(Color.GREEN)) return "green";
        if (c.equals(Color.YELLOW)) return "yellow";
        if (c.equals(Color.MAGENTA)) return "magenta";
        if (c.equals(Color.BLACK)) return "black";
        if (c.equals(Color.WHITE)) return "white";
        return "gray";
    }
}
