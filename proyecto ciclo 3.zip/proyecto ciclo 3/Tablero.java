import java.awt.*;
import java.util.*;

public class Tablero {
    private int size;
    private int[][] posiciones;
    private java.util.Map<Integer, Point> indiceACasilla;
    private java.util.List<Point> ordenEspiral;
    private int casillas;
    private Canvas canvas;
    private int cellSize = 50;
    private java.util.List<Robot> robots = new java.util.ArrayList<>();
    private java.util.List<Store> tiendas = new java.util.ArrayList<>();

    public Tablero(int size) {
        this.size = size;
        this.casillas = size * size;
        posiciones = new int[size][size];
        indiceACasilla = new java.util.HashMap<>();
        ordenEspiral = new java.util.ArrayList<>();
        Canvas.getCanvas("Tablero", size * cellSize + 2, size * cellSize + 2, Color.white);
        canvas = Canvas.getCanvas();

        generaIndicesPorRenglones();   // índices fila por fila
        generarOrdenEspiral();         // orden de animación en espiral
        dibujaTableroAnimado();        // animación inicial
    }

    // Índices lineales por renglones
    private void generaIndicesPorRenglones() {
        int index = 0;
        for (int fila = 0; fila < size; fila++) {
            for (int col = 0; col < size; col++) {
                posiciones[fila][col] = index;
                indiceACasilla.put(index, new Point(fila, col));
                index++;
            }
        }
    }

    // Genera lista de coordenadas en espiral para animación
    private void generarOrdenEspiral() {
        int top = 0, bottom = size - 1;
        int left = 0, right = size - 1;
        ordenEspiral.clear();

        while (top <= bottom && left <= right) {
            for (int col = left; col <= right; col++) ordenEspiral.add(new Point(top, col));
            top++;
            for (int row = top; row <= bottom; row++) ordenEspiral.add(new Point(row, right));
            right--;
            if (top <= bottom) {
                for (int col = right; col >= left; col--) ordenEspiral.add(new Point(bottom, col));
                bottom--;
            }
            if (left <= right) {
                for (int row = bottom; row >= top; row--) ordenEspiral.add(new Point(row, left));
                left++;
            }
        }
    }

    // Animación inicial en espiral
    private void dibujaTableroAnimado() {
        for (Point pos : ordenEspiral) {
            int fila = pos.x;
            int col = pos.y;
            int px = col * cellSize;
            int py = fila * cellSize;

            Shape rect = new java.awt.Rectangle(px, py, cellSize, cellSize);
            String color = ((fila + col) % 2 == 0) ? "white" : "black";
            canvas.draw("casilla_" + fila + "_" + col, color, rect);

            Shape lineaH = new java.awt.geom.Line2D.Double(0, py, size * cellSize, py);
            Shape lineaV = new java.awt.geom.Line2D.Double(px, 0, px, size * cellSize);
            canvas.draw("lineaH_" + fila + "_" + col, "#BBBBBB", lineaH);
            canvas.draw("lineaV_" + fila + "_" + col, "#BBBBBB", lineaV);

            canvas.wait(10);
        }
        // 👇 aseguramos que robots y tiendas queden encima
        refrescarElementos();
    }

    // Redibujo completo instantáneo
    public void dibujaTablero() {
        canvas.erase(this);

        for (int fila = 0; fila < size; fila++) {
            for (int col = 0; col < size; col++) {
                int px = col * cellSize;
                int py = fila * cellSize;
                Shape rect = new java.awt.Rectangle(px, py, cellSize, cellSize);
                String color = ((fila + col) % 2 == 0) ? "white" : "black";
                canvas.draw("fondo" + fila + "_" + col, color, rect);
            }
        }

        for (int fila = 0; fila <= size; fila++) {
            int y = fila * cellSize;
            Shape lineaH = new java.awt.geom.Line2D.Double(0, y, size * cellSize, y);
            canvas.draw("lineaH" + fila, "#BBBBBB", lineaH);
        }
        for (int col = 0; col <= size; col++) {
            int x = col * cellSize;
            Shape lineaV = new java.awt.geom.Line2D.Double(x, 0, x, size * cellSize);
            canvas.draw("lineaV" + col, "#BBBBBB", lineaV);
        }

        refrescarElementos(); // 👈 siempre al final
    }

    // Refresca robots y tiendas encima del tablero
    private void refrescarElementos() {
        for (Store t : tiendas) t.dibujar(canvas, this);
        for (Robot r : robots) r.dibujar(canvas, this);
    }

    public Point obtenerPixelDeIndice(int index) {
        Point casilla = indiceACasilla.get(index);
        int px = casilla.y * cellSize;
        int py = casilla.x * cellSize;
        return new Point(px, py);
    }

    public int getCellSize() { return cellSize; }

    public void agregarRobot(int indice, Color color) {
        robots.add(new Robot(indice, color));
        refrescarElementos();
    }

    public void agregarTienda(int indice, int tenges) {
        tiendas.add(new Store(indice, tenges));
        refrescarElementos();
    }

    public void moverRobot(int robotIndex, int nuevoIndice) {
        if (robotIndex < 0 || robotIndex >= robots.size()) return;
        Robot r = robots.get(robotIndex);
        int origen = r.getIndice();
        int paso = (nuevoIndice > origen) ? 1 : -1;
        for (int i = origen; i != nuevoIndice; i += paso) {
            r.setIndice(i);
            refrescarElementos();
            canvas.wait(200);
        }
        r.setIndice(nuevoIndice);
        refrescarElementos();
    }

    public java.util.List<Robot> getRobots() { return robots; }
    public java.util.List<Store> getTiendas() { return tiendas; }
}
