import java.awt.*;

public class SilkRoad {
    private Tablero tablero;

    public SilkRoad(int size) {
        tablero = new Tablero(size);
    }

    // Refresca el tablero completo (casillas + robots + tiendas)
    public void refrescarTablero() {
        tablero.dibujaTablero();
    }

    // Agregar un robot en una casilla de la espiral
    public void agregarRobot(int indice, Color color) {
        tablero.agregarRobot(indice, color);
    }

    // Agregar una tienda en una casilla de la espiral
    public void agregarTienda(int indice, int tenges) {
        tablero.agregarTienda(indice, tenges);
    }

    // Mover un robot paso a paso en la espiral
    public void moverRobot(int robotIndex, int nuevoIndice) {
        tablero.moverRobot(robotIndex, nuevoIndice);
    }

    // Acceso a robots y tiendas
    public java.util.List<Robot> getRobots() {
        return tablero.getRobots();
    }

    public java.util.List<Store> getTiendas() {
        return tablero.getTiendas();
    }
}
