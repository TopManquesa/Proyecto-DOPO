import java.awt.*;
import java.awt.geom.*;
import java.awt.image.*;
import java.util.*;
import javax.swing.*;

/**
 * Canvas es una clase para dibujar formas gráficas simples
 * en una ventana. ¡Ahora puedes especificar el tamaño!
 */
public class Canvas
{
    private static Canvas canvasSingleton;

    private JFrame frame;
    private CanvasPane canvas;
    private Graphics2D graphic;
    private Color backgroundColour;
    private Image canvasImage;
    private int width;
    private int height;

    private HashMap<Object, ShapeDescription> shapes;

    /**
     * Devuelve la instancia única de Canvas.
     * Si no existe, crea una con tamaño por defecto (600x600).
     */
    public static Canvas getCanvas()
    {
        if(canvasSingleton == null) {
            canvasSingleton = new Canvas("Canvas", 600, 600, Color.white);
        }
        return canvasSingleton;
    }

    /**
     * Devuelve la instancia única de Canvas con tamaño y color personalizados.
     * Solo tiene efecto la primera vez.
     */
    public static Canvas getCanvas(String title, int width, int height, Color bgColor)
    {
        if(canvasSingleton == null) {
            canvasSingleton = new Canvas(title, width, height, bgColor);
        }
        return canvasSingleton;
    }

    /**
     * Crea una nueva ventana Canvas.
     */
    private Canvas(String title, int width, int height, Color bgColor)
    {
        this.width = width;
        this.height = height;
        frame = new JFrame();
        canvas = new CanvasPane();
        frame.setContentPane(canvas);
        frame.setTitle(title);
        frame.setLocation(60, 60);
        canvas.setPreferredSize(new Dimension(width, height));
        backgroundColour = bgColor;
        frame.pack();
        shapes = new HashMap<>();
        frame.setVisible(true);
        // Inicialización del buffer de imagen
        canvasImage = canvas.createImage(width, height);
        graphic = (Graphics2D)canvasImage.getGraphics();
        graphic.setColor(backgroundColour);
        graphic.fillRect(0, 0, width, height);
        graphic.setColor(Color.black);
    }

    /**
     * Permite cambiar el tamaño de la ventana Canvas después de creada.
     */
    public void setCanvasSize(int width, int height) {
        this.width = width;
        this.height = height;
        canvas.setPreferredSize(new Dimension(width, height));
        frame.pack();
        // Actualiza el buffer de imagen
        canvasImage = canvas.createImage(width, height);
        graphic = (Graphics2D)canvasImage.getGraphics();
        graphic.setColor(backgroundColour);
        graphic.fillRect(0, 0, width, height);
        redraw();
    }

    /**
     * Borra todo lo dibujado por este objeto (por ejemplo, un tablero).
     */
    public void erase(Object reference)
    {
        shapes.remove(reference);
        redraw();
    }

    /**
     * Dibuja una forma en el canvas.
     */
    public void draw(Object reference, String color, Shape shape)
    {
        Color col = parseColor(color);
        shapes.put(reference, new ShapeDescription(shape, col));
        redraw();
    }

    /**
     * Borra toda la pantalla.
     */
    public void eraseAll()
    {
        shapes.clear();
        redraw();
    }

    /**
     * Espera X milisegundos.
     */
    public void wait(int milliseconds)
    {
        try
        {
            Thread.sleep(milliseconds);
        }
        catch (Exception e)
        {
            // ignorar
        }
    }

    /**
     * Redibuja todos los elementos.
     */
    private void redraw()
    {
        graphic.setColor(backgroundColour);
        graphic.fillRect(0, 0, width, height);
        for(ShapeDescription sd : shapes.values()) {
            graphic.setColor(sd.color);
            graphic.fill(sd.shape);
        }
        canvas.repaint();
    }

    /**
     * Permite parsear colores por nombre o hex.
     */
    private Color parseColor(String colorStr) {
        try {
            if (colorStr.startsWith("#")) {
                return Color.decode(colorStr);
            }
            // Algunos colores estándar
            switch(colorStr.toLowerCase()) {
                case "black": return Color.black;
                case "blue": return Color.blue;
                case "red": return Color.red;
                case "yellow": return Color.yellow;
                case "green": return Color.green;
                case "white": return Color.white;
                case "magenta": return Color.magenta;
                case "gray": return Color.gray;
                case "lightgray": return Color.lightGray;
                default: return Color.black;
            }
        } catch(Exception e) {
            return Color.black;
        }
    }

    /**
     * CanvasPane es el panel real donde se pinta.
     */
    private class CanvasPane extends JPanel
    {
        public void paint(Graphics g)
        {
            g.drawImage(canvasImage, 0, 0, null);
        }
    }

    /**
     * Clase interna para guardar la forma y color.
     */
    private class ShapeDescription
    {
        public Shape shape;
        public Color color;

        public ShapeDescription(Shape shape, Color color)
        {
            this.shape = shape;
            this.color = color;
        }
    }
}