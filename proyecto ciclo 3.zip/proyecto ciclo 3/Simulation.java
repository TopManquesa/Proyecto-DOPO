import java.io.*;
import java.util.*;
import java.awt.Color;

public class Simulation {
    private Tablero tablero;
    private TreeSet<Integer> robots;     // posiciones de robots
    private List<Store> stores;          // tiendas con posición y tenges
    private int dias;

    public Simulation(int size, int dias) {
        this.tablero = new Tablero(size); // tablero gráfico
        this.robots = new TreeSet<>();
        this.stores = new ArrayList<>();
        this.dias = dias;
    }

    public void procesarDias(BufferedReader br) throws IOException {
        StringBuilder out = new StringBuilder();

        for (int day = 1; day <= dias; day++) {
            StringTokenizer st = new StringTokenizer(br.readLine());
            int t = Integer.parseInt(st.nextToken());
            int x = Integer.parseInt(st.nextToken());

            if (t == 1) {
                // Nuevo robot
                robots.add(x);
                // 👇 opcional: mostrar en tablero
                tablero.agregarRobot(x % (tablero.getCellSize() * 10), Color.RED);
            } else {
                int c = Integer.parseInt(st.nextToken());
                Store s = new Store(x, c);
                stores.add(s);
                // 👇 opcional: mostrar en tablero
                tablero.agregarTienda(x % (tablero.getCellSize() * 10), c);
            }

            long profitToday = calcularBeneficio();
            out.append(profitToday).append("\n");
        }

        System.out.print(out.toString());
    }

    private long calcularBeneficio() {
        if (robots.isEmpty() || stores.isEmpty()) return 0;

        long total = 0;
        for (Store store : stores) {
            int pos = store.getIndice();
            int tenges = store.getTenges();

            // Buscar robot más cercano
            Integer left = robots.floor(pos);
            Integer right = robots.ceiling(pos);

            int dist = Integer.MAX_VALUE;
            if (left != null) dist = Math.min(dist, Math.abs(pos - left));
            if (right != null) dist = Math.min(dist, Math.abs(pos - right));

            long profit = tenges - dist;
            if (profit > 0) total += profit;
        }
        return total;
    }

    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.parseInt(br.readLine().trim());

        Simulation sim = new Simulation(10, n); // tablero 10x10
        sim.procesarDias(br);
    }
}
