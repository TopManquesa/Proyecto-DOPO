import java.awt.*;

public class Store {
    private int indice;
    private int tenges;
    private String id; // id único y persistente

    public Store(int indice, int tenges) {
        this.indice = indice;
        this.tenges = tenges;
        this.id = "store_" + System.identityHashCode(this);
    }

    public int getIndice() { return indice; }
    public void setIndice(int indice) { this.indice = indice; }

    public int getTenges() { return tenges; }
    public void setTenges(int tenges) { this.tenges = tenges; }

    public void dibujar(Canvas canvas, Tablero tablero) {
        Point p = tablero.obtenerPixelDeIndice(indice);
        int cellSize = tablero.getCellSize();

        int x = p.x + cellSize / 4;
        int y = p.y + cellSize / 4;
        int size = cellSize / 2;

        Shape square = new java.awt.Rectangle(x, y, size, size);

        // 👇 siempre el mismo id, pero se redibuja en la nueva posición
        canvas.draw(id, "yellow", square);
    }
}
